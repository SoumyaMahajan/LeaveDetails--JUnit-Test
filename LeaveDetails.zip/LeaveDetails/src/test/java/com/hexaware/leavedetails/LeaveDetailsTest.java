package com.hexaware.leavedetails;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import com.hexaware.leavedetails.model.LeaveDetails;
import com.hexaware.leavedetails.model.LeaveStatus;
import com.hexaware.leavedetails.model.LeaveType;

public class LeaveDetailsTest {

	@Test
	public void testConstructor() {
		
		LeaveDetails leaveDetails = new LeaveDetails();
		assertNotNull(leaveDetails);
		LeaveDetails leaveDetailsNew = new LeaveDetails(1, 101, LeaveType.PL, LeaveStatus.Accepted, new Date(), new Date(), "Personal Emergency");
        assertEquals(1, leaveDetailsNew.getLeaveID());
        assertEquals(101, leaveDetailsNew.getEmpID());
        assertEquals(LeaveType.PL, leaveDetailsNew.getLeaveType());
        assertEquals(LeaveStatus.Accepted, leaveDetailsNew.getLeaveStatus());
        assertNotNull(leaveDetailsNew.getLeaveStartDate());
        assertNotNull(leaveDetailsNew.getLeaveEndDate());
        assertEquals("Personal Emergency", leaveDetailsNew.getLeaveReason());
		}
	
	@Test
	public void testGettersAndSetters() {
		
		LeaveDetails leaveDetails = new LeaveDetails();
        leaveDetails.setLeaveID(2);
        leaveDetails.setEmpID(102);
        leaveDetails.setLeaveType(LeaveType.EL);
        leaveDetails.setLeaveStatus(LeaveStatus.Pending);
        leaveDetails.setLeaveStartDate(new Date());
        leaveDetails.setLeaveEndDate(new Date());
        leaveDetails.setLeaveReason("Headache");

        assertEquals(2, leaveDetails.getLeaveID());
        assertEquals(102, leaveDetails.getEmpID());
        assertEquals(LeaveType.EL, leaveDetails.getLeaveType());
        assertEquals(LeaveStatus.Pending, leaveDetails.getLeaveStatus());
        assertNotNull(leaveDetails.getLeaveStartDate());
        assertNotNull(leaveDetails.getLeaveEndDate());
        assertEquals("Headache", leaveDetails.getLeaveReason());
    }
	
	
	@Test
    public void testLeaveDetailsToString() {
        LeaveDetails leaveDetails = new LeaveDetails(3, 103, LeaveType.ML, LeaveStatus.Rejected, new Date(), new Date(), "Family Emergency");

        String expectedString = "LeaveDetails [leaveID=3, empID=103, leaveType=ML, leaveStatus=Rejected, leaveStartDate=" + leaveDetails.getLeaveStartDate() +
                ", leaveEndDate=" + leaveDetails.getLeaveEndDate() + ", leaveReason=Family Emergency]";

        assertEquals(expectedString, leaveDetails.toString());
    }
	}
	


