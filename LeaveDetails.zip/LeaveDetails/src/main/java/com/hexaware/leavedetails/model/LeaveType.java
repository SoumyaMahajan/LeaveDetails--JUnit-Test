package com.hexaware.leavedetails.model;

public enum LeaveType {

	  EL, PL, ML
}
