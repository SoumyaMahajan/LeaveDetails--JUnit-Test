package com.hexaware.leavedetails;

import java.util.Date;

import com.hexaware.leavedetails.model.LeaveDetails;
import com.hexaware.leavedetails.model.LeaveStatus;
import com.hexaware.leavedetails.model.LeaveType;

public class App {

  public static void main(String[] args) {
	  
	  LeaveDetails leaveDetailsNew = new LeaveDetails(3, 103, LeaveType.ML, LeaveStatus.Rejected, new Date(), new Date(), "Family Emergency");
	  System.out.println(leaveDetailsNew);
  }

}
