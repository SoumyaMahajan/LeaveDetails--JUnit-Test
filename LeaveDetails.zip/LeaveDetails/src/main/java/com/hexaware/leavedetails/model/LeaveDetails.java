package com.hexaware.leavedetails.model;

import java.util.Date;

public class LeaveDetails {
         
	    private int leaveID;
	    private int empID;
	    private LeaveType leaveType;
	    private LeaveStatus leaveStatus;
	    private Date leaveStartDate;
	    private Date leaveEndDate;
	    private String leaveReason;
	    
		public LeaveDetails() {
			
		}

		public LeaveDetails(int leaveID, int empID, LeaveType leaveType, LeaveStatus leaveStatus, Date leaveStartDate,
				Date leaveEndDate, String leaveReason) {
			
			this.leaveID = leaveID;
			this.empID = empID;
			this.leaveType = leaveType;
			this.leaveStatus = leaveStatus;
			this.leaveStartDate = leaveStartDate;
			this.leaveEndDate = leaveEndDate;
			this.leaveReason = leaveReason;
		}

		public int getLeaveID() {
			return leaveID;
		}

		public void setLeaveID(int leaveID) {
			this.leaveID = leaveID;
		} 

		public int getEmpID() {
			return empID;
		}

		public void setEmpID(int empID) {
			this.empID = empID;
		}

		public LeaveType getLeaveType() {
			return leaveType;
		}

		public void setLeaveType(LeaveType leaveType) {
			this.leaveType = leaveType;
		}

		public LeaveStatus getLeaveStatus() {
			return leaveStatus;
		}

		public void setLeaveStatus(LeaveStatus leaveStatus) {
			this.leaveStatus = leaveStatus;
		}

		public Date getLeaveStartDate() {
			return leaveStartDate;
		}

		public void setLeaveStartDate(Date leaveStartDate) {
			this.leaveStartDate = leaveStartDate;
		}

		public Date getLeaveEndDate() {
			return leaveEndDate;
		}

		public void setLeaveEndDate(Date leaveEndDate) {
			this.leaveEndDate = leaveEndDate;
		}

		public String getLeaveReason() {
			return leaveReason;
		}

		public void setLeaveReason(String leaveReason) {
			this.leaveReason = leaveReason;
		}

		@Override
		public String toString() {
			return "LeaveDetails [leaveID=" + leaveID + ", empID=" + empID + ", leaveType=" + leaveType
					+ ", leaveStatus=" + leaveStatus + ", leaveStartDate=" + leaveStartDate + ", leaveEndDate="
					+ leaveEndDate + ", leaveReason=" + leaveReason + "]";
		}
		
		
	    
	    
}
