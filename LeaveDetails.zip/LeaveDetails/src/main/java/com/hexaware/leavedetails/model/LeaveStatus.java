package com.hexaware.leavedetails.model;

public enum LeaveStatus {

	    Pending, Accepted, Rejected
}
